package com.teamup.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

public class SMSReciever extends BroadcastReceiver {

    static String TAG = SMSReciever.class.getName();
    static String KEY_VALID_THROUGH ="validfor";
    @Override
    public void onReceive(Context context, Intent intent) {

        Log.d(TAG, "onReceive: ");
        String from = "", body = "";

        if(intent.getExtras()==null)
            return;

        Object[] smsObjects = (Object[]) intent.getExtras().get("pdus");
        SmsMessage[] smsMessages = new SmsMessage[smsObjects.length];

        for (int i = 0; i < smsObjects.length ; i++) {
            smsMessages[i] = SmsMessage.createFromPdu((byte[])smsObjects[i]);
            from = smsMessages[i].getOriginatingAddress();
            body = smsMessages[i].getMessageBody();
            String code = body.substring(0,body.indexOf(" "));

            Log.d(TAG, "onReceive: "+body);
            Log.d(TAG, "onReceive: code = "+code);
            Log.d(TAG, "onReceive: from = "+from);

           setOTP(context,code );
        }


    }

    public static void setOTP(Context context , String code){
        context.getSharedPreferences(TAG, Context.MODE_PRIVATE)
                .edit()
                .putString(TAG, code)
                .putLong(KEY_VALID_THROUGH, System.currentTimeMillis()+60*1000)
                .apply();
    }


    public static String getCode(Context context){
       return context.getSharedPreferences(TAG, Context.MODE_PRIVATE)
                .getString(TAG, "");
    }

    public static boolean isCodeValid(Context context){

        return context.getSharedPreferences(TAG, Context.MODE_PRIVATE)
                .getLong(KEY_VALID_THROUGH, System.currentTimeMillis()) > System.currentTimeMillis();
    }
}
