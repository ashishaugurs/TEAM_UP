package com.teamup.utils;


/**
 * Created by ashish on 28/04/18.
 */
public class AppConstant {
    public static final String YOUTUBE_API_KEY = "AIzaSyCG25IwSEZcJuF5Te7kko9XawkHaEJ48Ws";
    public static final int RECOVERY_REQUEST = 1;
    public static final long BOUNCING_EFFECT_TIME = 100;
    public static final String IS_USER_LOGIN ="userLogin";
    public static final String LOGIN_TYPE ="login_type";
    public static final String COUNTRY_CODE ="country_code";

    public static final String OTP_STATUS ="otp_status";

    public static final String HOUSE_NUMBER ="house";

    public static final String LIST_POSITION ="position";



    public static final String USER_ID ="user_id" ;
    public static final String EMAIL ="email" ;
    public static final String Player ="player" ;

    public static final String NAME ="name" ;
    public static final String LAST_NAME ="last_name" ;
    public static final String PASSWORD ="last_name" ;
    public static final String MOBILE ="mobile" ;
    public static final String LOCALE ="locale" ;
    public static final String IMAGE ="item_img";
    public static final boolean fingerPrint=false;
    public static final String FINGER ="finger" ;
    public static final String MERCHANT_ID ="merchant_id";
    public static final String RESTAURANT_NAME ="restaurant_name";


    public static final String OTP ="otp";
    public static final String FAV = "status";
    public static final String DATA_RESULT = "" ;
    public static final String KEY ="key" ;
    public static final String VALUE ="value" ;
    public static final String RES_LAT ="res_lat";
    public static final String RES_LNG ="res_lng";
    public static final String FREE_DELIVERY = "free_delivery" ;
    public static final String OPEN_RES = "open_res";
    public static final String OFFER_FLAG ="offer" ;
    public static final String TEAMTYPE = "teamtype";
    public static final String NAV_TYPE = "type_nav" ;
    public static final String LIST_VALUE = "list_value" ;
    public static String FIREBASE_TOKEN = "";


    public static String workSansBold = "Montserrat-SemiBold.ttf";
    public static String roboto = "Roboto-Regular.ttf";
    public static String robotoMedium = "Roboto-Medium.ttf";
    public static String sfPro = "SFProText-Regular.ttf";
    public static String sfProBold = "SFProText-Semibold.otf";
    public static String sfProMedium = "SFProText-Medium.ttf";
    public static String montserratMedium = "Montserrat-Medium.ttf";
    public static String SFProDisplayRegular="SF-Pro-Display-Regular.otf";
    public static String SFProDisplaySemibold="SF-Pro-Display-Semibold.otf";

    public static final String PAYPAL_CLIENT_ID = "AT0TTRRH9q5Z50VlVa0ZGG_KhrzcN5DoQMWeCVwV3lwzmAaakShidU9-E7PQ6d2taHrdluj9HzzXXWbQ";
    public static final String PAYPAL_CLIENT_SECRET = "EJ-HD2E7RqgqQU7hNnyRsByTeLYhgJ_SGoyRNJkgPlC3u0Eb2St7ZoOKmyCYdEpTsJxKMsTg6xUKNd2r";

    public static final String DEFAULT_CURRENCY = "USD";

    // Our php+mysql server urls
    public static final String URL_PRODUCTS = "http://192.168.0.104/PayPalServer/v1/products";
    public static final String URL_VERIFY_PAYMENT = "http://192.168.0.104/PayPalServer/v1/verifyPayment";


    public static  boolean flag=false;
    public static  int tabValue=0;




}
