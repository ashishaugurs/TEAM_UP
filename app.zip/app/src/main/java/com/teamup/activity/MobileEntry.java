package com.teamup.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.teamup.R;
import com.teamup.model.Player;
import com.teamup.utils.AppConstant;
import com.teamup.utils.CommonUtils;
import com.teamup.utils.SmsUtils;


public class MobileEntry extends BaseActivity {
    EditText inputMobile;
    Activity context;
    TextView headerText,contentDes;
    LinearLayout team_mobile;

    @Override
    protected void onResume(){
        super.onResume();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try{
           setContentView(R.layout.mobile_verification);
           setBlankToolbar();
           context=this;
           findId();
           contentDes.setTypeface(CommonUtils.setFontTextNormal(context));
           headerText.setTypeface(CommonUtils.setFontTextHeader(context));
           inputMobile.setTypeface(CommonUtils.setFontTextNormal(context));
           inputMobile.addTextChangedListener(new CommonUtils.CustomTextWatcher(context,inputMobile,R.mipmap.active_side,null,R.mipmap.side_mobile));
           headerText.setText("Verification");
           contentDes.setText("We'll text you a confirmation code to\nsecure your account.");
           inputMobile.requestFocus();
           inputMobile.addTextChangedListener(new TextWatcher() {
               @Override
               public void onTextChanged(CharSequence s, int start, int before, int count) {



               }

               @Override
               public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                   // dataset change UI completion
               }

               @Override
               public void afterTextChanged(Editable s) {

               }
           });

           team_mobile.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   CommonUtils.hideSoftKeyboard(context);
               }
           });
           backclick();
       }catch (Exception e){

       }

       findViewById(R.id.confirm)
               .setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {

                       if(inputMobile.getText().length()!=10){
                        return;
                       }

                       Intent intent = new Intent(context,TeamOTP.class);
                       //send player detail upfront

                       Player player = (Player) getIntent().getSerializableExtra(AppConstant.Player);
                       player.setPhone(inputMobile.getText().toString());
                       intent.putExtra(AppConstant.Player, player);

                       SmsUtils.sendOTP(MobileEntry.this, player.getPhone());

                       startActivity(intent);
                   }
               });
    }

    private void findId() {
        inputMobile=findViewById(R.id.email_text);
        headerText=findViewById(R.id.textView);
        contentDes=findViewById(R.id.textView2);
        team_mobile=findViewById(R.id.team_mobile);
    }

 }
