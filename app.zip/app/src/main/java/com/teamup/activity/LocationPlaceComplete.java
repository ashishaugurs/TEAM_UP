package com.teamup.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.teamup.R;

public class LocationPlaceComplete extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_sport);
    }
}
